Note of the author

Hello, If you want to use this font, please contact me before any commercial use.

My fonts are not allowed for: TV / Cinema / Sex content / Politics / Religion.

Thank's, I hope my work will suit your project, be positive, keep creating!

Maelle.K | T.B

maellekeita@gmail.com

