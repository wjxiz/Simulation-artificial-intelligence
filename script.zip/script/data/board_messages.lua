--------------------
-- Board messages
--------------------
BOARD_MESSAGE_GREETINGS = "Simulation en cours..."
BOARD_MESSAGE_NPC_ENCOUNTERED = "Gus a rencontré un PNJ !"

BOARD_MESSAGE_NO_DATA = "-"
BOARD_MESSAGE_YES = "Oui"
BOARD_MESSAGE_NO = "Non"
--------------------
-- Labels
--------------------
BOARD_LABEL_IDENTITY = "Identité"
BOARD_LABEL_PROFILE = "Profil"
BOARD_LABEL_FIRST_ENCOUNTER = "Première rencontre"
BOARD_LABEL_QUEST_COMPLETED = "Quête validée"



