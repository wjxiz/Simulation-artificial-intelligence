--------------------
-- Dialogues
--------------------
DIALOGUE_GUS_WHATS_YOUR_NAME = "Comment tu t'appelles ?"

DIALOGUE_GUS_NICE_TO_MEET_YOU = "Enchante %s, Moi c'est %s !"


DIALOGUE_GUS_SEE_U_AGAIN = "Salut! C'est encore moi Gus."
DIALOGUE_GUS_BYE= "C'est domage, Au revoir."
DIALOGUE_GUS_HATEBYE = "T'es pas amicale du tout!! Au revoir!!!"

DIALOGUE_GUS_MEET_AGAIN = "Bonjour %s, je suis %s, C'est la 2eme fois qu'on rencontre. Vous allez bien?"
DIALOGUE_GUS_ASK_NAME_AGAIN = "C'est la 2eme fois qu'on rencontre, est-ce que tu peut donner ton nom?"

DIALOGUE_GUS_COMPLIMENT = "Vous avez l'air vraiment formidable pourtant, j'aimerais connaître votre nom."
DIALOGUE_GUS_AMADOUE = "Vous etes amicale, c'est ma chance si je peut savoir ton nom s'il te plait."
DIALOGUE_GUS_SUPPLIE = "J'ai vrai besoin de savoir ton nom, s'il vous plait..."
DIALOGUE_GUS_AGRESSIF = "Allez, bon sang, secoue-toi, donne-moi ton nom !"



DIALOGUE_NPC_MY_NAME_IS = "Je m'appelle %s."

DIALOGUE_NPC_GIVENAME_ARROGANT = "Mon nom est tres distingue, %s, moi c'est %s."
DIALOGUE_NPC_GIVENAME_CHARMEUR = "Moi c'est %s. Ravie de te rencontrer mon chou !"
DIALOGUE_NPC_GIVENAME_AGRESSIF = "Mon nom est %s t'es con..."
DIALOGUE_NPC_GIVENAME_TIMIDE   = "Je m'appelles %s...Enchante %s... "

DIALOGUE_NPC_I_WONT_GIVE_MY_NAME = "Je refuse de te donner mon nom."
DIALOGUE_NPC_BYE= "Au revoir!"
DIALOGUE_NPC_MEET_AGAIN = "Ah oui,Bonjour. ca va ."

DIALOGUE_NPC_NEGOCIATE_NO = "Non, c'est pas possible"



DIALOGUE_CHARMEUR_REFUSE = "Ah non mon p’tit loup, t’es mignon mais je te donnerai pas mon nom ! "
DIALOGUE_AGRESSIF_REFUSE = "T'es qui alors? Je ne te connait pas du tout! Au large!"
DIALOGUE_ARROGANT_REFUSE = "Je ne vais pas dire mon nom si tu me dis le tien ~ "
DIALOGUE_TIMIDE_REFUSE = "Euh non... Désolé... Je peux pas vous parler là tout de suite..."
